import MainNavbar from '@/components/Navbar/MainNavbar';

const Navbar = () => {
  return (
    <>
      <MainNavbar />
    </>
  );
};

export default Navbar;
