import { motion } from 'framer-motion';
import Timer from '../Timer';
import ScrollIndicator from './ScrollIndicator';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { translateds } from '@/context/TranslateContext';
import { useGetCompetitions } from '@/services/competitions';
import { Competition } from '@/services/competitions/types';
import { findNearestFutureRace } from '@/utils/nearestRace';

const HeaderSection = () => {
  const navigate = useNavigate();
  const [svgColor, setSvgColor] = useState<boolean>(false);
  const [nearestRace, setNearestRace] = useState<Competition | null>(null);
  const [backgroundImage, setBackgroundImage] = useState<string>('');
  const [mobileImage, setMobileImage] = React.useState<string>('');

  const { data: allCompetitionsData } = useGetCompetitions();
  const competitions = allCompetitionsData?.data || [];
  console.log(backgroundImage, 'backgroundImagebackgroundImage');
  useEffect(() => {
    if (competitions && competitions.length > 0) {
      const nextRace = findNearestFutureRace(competitions);
      setNearestRace(nextRace);

      if (nextRace?.bottom_image) {
        setBackgroundImage(nextRace.bottom_image);
      }
      if (nextRace?.mobile_image) {
        setMobileImage(nextRace?.mobile_image);
      }
    }
  }, [competitions]);

  const [ismobile, setIsMobile] = React.useState<boolean>(false);
  const handleScreen = () => {
    setIsMobile(window.innerWidth <= 768);
  }

  console.log(mobileImage, 'mobile_image')
  React.useEffect(() => {
    handleScreen();
    window.addEventListener("resize", handleScreen);
    return () => window.removeEventListener("resize", handleScreen);
  }, []);

  return (
    <header
      className="relative bg-cover bg-center h-screen flex justify-center items-center overflow-hidden"
      style={{
        backgroundImage: ismobile ? `url(${mobileImage})` : `url(${backgroundImage})`,
      }}>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="absolute top-0 left-0 w-full h-full bg-[rgba(0,0,0,0.36)]"
      />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
        className="absolute bottom-0 left-0 w-full h-[50%] bg-gradient-to-t from-black to-transparent"
      />

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="mx-auto px-6 sm:px-12 md:px-16 lg:px-24 xl:px-52 relative z-[1] text-center flex justify-center items-center flex-col">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-white font-medium text-[24px] sm:text-[32px] md:text-[40px] lg:text-[48px] xl:text-[52px] leading-tight">
          {nearestRace?.name}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="text-white font-normal text-[12px]  md:text-lg pt-[28px] max-w-[980px]">
          {nearestRace?.text}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.9 }}>
          <Timer />
        </motion.div>

        <motion.button
          onMouseEnter={() => setSvgColor(true)}
          onMouseLeave={() => setSvgColor(false)}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          whileHover={{ scale: 1.05 }}
          onClick={() => {
            navigate(`/competition/${nearestRace?.slug}`)
          }}
          whileTap={{ scale: 0.95 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-white hover:bg-[#0B98A1] hover:text-white transition-colors flex items-center gap-3 cursor-pointer text-[#0B98A1] rounded-full md:py-[16px] py-[13px] px-[20px] md:px-[28px] text-[14px] md:text-base">
          <span>
            <svg
              id="iconSvg"
              className=" w-[20px] h-[20px] lg:w-[28px] md:h-[28px]"
              viewBox="0 0 28 28"
              fill={`${!svgColor ? '#0B98A1' : 'white'}`}
              xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_274_173)">
                <path
                  d="M27.1181 11.9933C26.0578 11.8662 25.0059 11.6761 23.9681 11.424C24.5022 10.6812 24.7717 9.78072 24.7334 8.86666C24.7334 7.22866 23.2681 2.92599 22.3021 0.984656C22.1442 0.667869 21.8207 0.467651 21.4668 0.467651C21.1128 0.467651 20.7893 0.667869 20.6314 0.984656C19.6654 2.92599 18.2001 7.22866 18.2001 8.86666C18.1967 9.30414 18.2501 9.74022 18.3588 10.164C17.6494 10.0473 16.9588 9.96332 16.2681 9.90732C16.3107 9.71894 16.3326 9.52647 16.3334 9.33332C16.3334 7.78693 15.0798 6.53332 13.5334 6.53332C11.9871 6.53332 10.7334 7.78693 10.7334 9.33332C10.7336 9.52804 10.7556 9.72213 10.7988 9.91199C10.0754 9.97266 9.37545 10.0567 8.70345 10.1687C8.81608 9.74395 8.87102 9.30602 8.86678 8.86666C8.86678 7.22866 7.40145 2.92599 6.43545 0.984656C6.27756 0.667869 5.95407 0.467651 5.60012 0.467651C5.24616 0.467651 4.92267 0.667869 4.76478 0.984656C4.3388 1.87973 3.9618 2.79731 3.63545 3.73332H3.73345C4.49618 3.73198 5.19243 4.16714 5.52545 4.85332C6.5288 7.03074 7.3347 9.29382 7.93345 11.6153C8.08182 11.4501 8.21315 11.2703 8.32545 11.0787C8.38792 11.1099 8.45633 11.1274 8.52612 11.13H8.60545C10.0798 10.8806 11.5716 10.7479 13.0668 10.7333C11.2281 11.6667 9.33345 13.0107 9.33345 14.4667C9.33345 17.2667 17.2668 18.6667 14.9334 20.0667C12.7074 21.4013 5.80545 21.8867 2.33345 26.796C2.23081 26.94 2.21842 27.1297 2.30144 27.2859C2.38447 27.442 2.54864 27.5379 2.72545 27.5333H13.6454C13.8729 27.5317 14.092 27.4471 14.2614 27.2953C15.7459 26.0768 17.3839 25.0586 19.1334 24.2667C29.8668 19.1333 19.6001 16.3333 15.8668 14.9333C13.3701 14 14.6301 12.0167 15.7361 10.808C15.8668 10.808 16.0021 10.808 16.1281 10.836C16.8981 10.8967 17.6541 10.99 18.4614 11.1253C18.5558 11.1363 18.6513 11.1201 18.7368 11.0787C19.0678 11.6601 19.5859 12.1124 20.2068 12.362C20.1997 12.4146 20.1997 12.468 20.2068 12.5207C20.269 13.2708 20.0943 14.0216 19.7074 14.6673C19.638 14.77 19.6122 14.8961 19.6359 15.0178C19.6595 15.1395 19.7306 15.2468 19.8334 15.316C19.9022 15.3645 19.9829 15.3935 20.0668 15.4C20.222 15.4002 20.3672 15.3233 20.4541 15.1947C20.9336 14.4174 21.1632 13.5118 21.1121 12.6H21.4621H21.8121C21.7581 13.5165 21.9879 14.4274 22.4701 15.2087C22.562 15.3347 22.7109 15.4065 22.8668 15.4C22.9599 15.4002 23.0509 15.3726 23.1281 15.3207C23.231 15.2514 23.3021 15.1442 23.3257 15.0225C23.3493 14.9008 23.3236 14.7747 23.2541 14.672C22.8672 14.0263 22.6926 13.2755 22.7548 12.5253C22.7619 12.4727 22.7619 12.4193 22.7548 12.3667C22.9312 12.2948 23.1 12.2057 23.2588 12.1007C23.3181 12.1878 23.4081 12.2494 23.5108 12.2733C24.6692 12.569 25.8463 12.7857 27.0341 12.922H27.0668C27.3245 12.9362 27.5449 12.7387 27.5591 12.481C27.5733 12.2233 27.3758 12.0028 27.1181 11.9887V11.9933ZM11.2001 14.9333C10.9424 14.9333 10.7334 14.7244 10.7334 14.4667C10.7334 14.2089 10.9424 14 11.2001 14C11.4578 14 11.6668 14.2089 11.6668 14.4667C11.6668 14.7244 11.4578 14.9333 11.2001 14.9333ZM12.6001 26.1333C12.3424 26.1333 12.1334 25.9244 12.1334 25.6667C12.1334 25.4089 12.3424 25.2 12.6001 25.2C12.8578 25.2 13.0668 25.4089 13.0668 25.6667C13.0668 25.9244 12.8578 26.1333 12.6001 26.1333ZM12.6001 23.3333C12.3424 23.3333 12.1334 23.1244 12.1334 22.8667C12.1334 22.6089 12.3424 22.4 12.6001 22.4C12.8578 22.4 13.0668 22.6089 13.0668 22.8667C13.0668 23.1244 12.8578 23.3333 12.6001 23.3333ZM21.4668 18.6667C21.7245 18.6667 21.9334 18.8756 21.9334 19.1333C21.9334 19.3911 21.7245 19.6 21.4668 19.6C21.209 19.6 21.0001 19.3911 21.0001 19.1333C21.0001 18.8756 21.209 18.6667 21.4668 18.6667ZM20.0668 19.6C20.0668 19.8577 19.8578 20.0667 19.6001 20.0667C19.3424 20.0667 19.1334 19.8577 19.1334 19.6C19.1334 19.3423 19.3424 19.1333 19.6001 19.1333C19.8578 19.1333 20.0668 19.3423 20.0668 19.6ZM19.1334 17.7333C19.3912 17.7333 19.6001 17.9423 19.6001 18.2C19.6001 18.4577 19.3912 18.6667 19.1334 18.6667C18.8757 18.6667 18.6668 18.4577 18.6668 18.2C18.6668 17.9423 18.8757 17.7333 19.1334 17.7333ZM21.4668 11.2C20.2814 11.2 19.6001 10.3507 19.6001 8.86666C19.6001 8.60892 19.809 8.39999 20.0668 8.39999C20.3245 8.39999 20.5334 8.60892 20.5334 8.86666C20.5334 10.2667 21.2101 10.2667 21.4668 10.2667C21.7245 10.2667 21.9334 10.4756 21.9334 10.7333C21.9334 10.9911 21.7245 11.2 21.4668 11.2Z"
                  fill={`${!svgColor ? '#0B98A1' : 'white'}`}
                />
                <path
                  d="M2.72067 21.2613C3.20517 20.4837 3.45473 19.5827 3.43933 18.6667H3.73333H4.02733C4.00922 19.5875 4.25888 20.4937 4.746 21.2753C4.83604 21.3986 4.9807 21.4701 5.13333 21.4667C5.22641 21.4669 5.31742 21.4392 5.39467 21.3873C5.49752 21.3181 5.56861 21.2108 5.59225 21.0891C5.61589 20.9674 5.59013 20.8413 5.52067 20.7387C5.12791 20.0968 4.93312 19.3533 4.96067 18.6013C4.95743 18.5601 4.9496 18.5195 4.93733 18.48C6.40733 18.0133 7.462 16.6133 7.462 14.3593C7.462 12.4693 5.79133 7.504 4.68533 5.264C4.50715 4.89798 4.13575 4.66571 3.72867 4.66571C3.32158 4.66571 2.95018 4.89798 2.772 5.264C1.67067 7.504 0 12.4693 0 14.3593C0 16.604 1.05467 17.9993 2.52467 18.48C2.52024 18.5203 2.52024 18.561 2.52467 18.6013C2.55221 19.3533 2.35743 20.0968 1.96467 20.7387C1.8952 20.8413 1.86945 20.9674 1.89309 21.0891C1.91672 21.2108 1.98781 21.3181 2.09067 21.3873C2.16261 21.4358 2.24664 21.4633 2.33333 21.4667C2.48856 21.4669 2.63374 21.3899 2.72067 21.2613ZM1.4 14.3593C1.4 14.1016 1.60893 13.8927 1.86667 13.8927C2.1244 13.8927 2.33333 14.1016 2.33333 14.3593C2.33333 15.6707 2.8 16.3333 3.73333 16.3333C3.99107 16.3333 4.2 16.5423 4.2 16.8C4.2 17.0577 3.99107 17.2667 3.73333 17.2667C2.27267 17.2667 1.4 16.1793 1.4 14.3593Z"
                  fill={`${!svgColor ? '#0B98A1' : 'white'}`}
                />
                <path
                  d="M13.5333 5.13333C13.791 5.13333 14 4.9244 14 4.66666V3.73333C14 3.4756 13.791 3.26666 13.5333 3.26666C13.2756 3.26666 13.0667 3.4756 13.0667 3.73333V4.66666C13.0667 4.9244 13.2756 5.13333 13.5333 5.13333Z"
                  fill={`${!svgColor ? '#0B98A1' : 'white'}`}
                />
                <path
                  d="M10.7939 5.52532C10.8773 5.67037 11.0317 5.75992 11.199 5.76026C11.3663 5.76059 11.521 5.67164 11.605 5.52692C11.6889 5.3822 11.6893 5.2037 11.6059 5.05865L11.1392 4.25132C11.0104 4.02709 10.7241 3.94978 10.4999 4.07865C10.2757 4.20752 10.1984 4.49376 10.3272 4.71798L10.7939 5.52532Z"
                  fill={`${!svgColor ? '#0B98A1' : 'white'}`}
                />
                <path
                  d="M15.6332 5.69796C15.7408 5.76029 15.8688 5.7771 15.9888 5.74469C16.1089 5.71227 16.211 5.6333 16.2726 5.5253L16.7392 4.71796C16.8226 4.57291 16.8222 4.39441 16.7383 4.24969C16.6544 4.10497 16.4996 4.01603 16.3323 4.01636C16.165 4.01669 16.0106 4.10625 15.9272 4.2513L15.4606 5.05863C15.3983 5.16621 15.3814 5.29421 15.4138 5.41423C15.4463 5.53426 15.5252 5.63639 15.6332 5.69796Z"
                  fill={`${!svgColor ? '#0B98A1' : 'white'}`}
                />
              </g>
              <defs>
                <clipPath id="clip0_274_173">
                  <rect width="28" height="28" />
                </clipPath>
              </defs>
            </svg>
          </span>

          <Link style={{ textTransform: "capitalize" }} to={`/competition/${nearestRace?.slug}`}>
            {translateds('discover_races')}
          </Link>
        </motion.button>
      </motion.div>
      <ScrollIndicator />
    </header>
  );
};

export default HeaderSection;
