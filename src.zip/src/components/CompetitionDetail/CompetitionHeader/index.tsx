const CompetitionHeader = () => {
  return (
    <>
      <div>
        <div className="main-container">
          {/* <p className="text-[#8FEDA0] flex items-center text-[13px] lg:text-base gap-[2px] pt-[20px] pb-[28px]">
            <span>
              <img src={Date} alt="Date" />
            </span>
            {translateds('Registration_dates')}: {start} - {end}
          </p> */}
        </div>
      </div>
    </>
  );
};

export default CompetitionHeader;
