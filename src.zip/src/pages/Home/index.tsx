import {
  FAQSection,
  HeaderSection,
  RaceScenes,
  SendMail,
  Statistics,
  UpcomingRaces,
} from '@/components/Home';
import { useGetSeoOfPage } from '@/services/seo';
import { Helmet } from 'react-helmet-async';

const Home = () => {
    const { data: homeData } = useGetSeoOfPage('home');
    const seoData = homeData?.data.find((item) => item.key === 'home');
  return (
    <>
      <Helmet>
        <title>{seoData?.meta_title}</title>
        <meta name="description" content={seoData?.meta_description} />
        <link rel="canonical" href={window.location.href} />
        <meta property="og:title" content={seoData?.meta_title} />
      </Helmet>
      <HeaderSection />
      <Statistics />
      <UpcomingRaces />
      <FAQSection />
      <RaceScenes />
      <SendMail />
    </>
  );
};

export default Home;
